﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            firstpanel.BringToFront();
            panel0.Height = button1.Height;
            panel0.Top = button1.Top;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Secondpanel.BringToFront();
            panel0.Height = button2.Height;
            panel0.Top = button2.Top;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel0.Height = button4.Height;
            panel0.Top = button4.Top;
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel0.Height = button6.Height;
            panel0.Top = button6.Top;
        }

        private void userControl11_Load(object sender, EventArgs e)
        {

        }

        private void Secondpanel_Load(object sender, EventArgs e)
        {

        }

        private void panel0_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel0.Height = button3.Height;
            panel0.Top = button3.Top;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel0.Height = button5.Height;
            panel0.Top = button5.Top;
        }
    }
}
